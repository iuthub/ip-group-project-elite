@component('mail::message')
# Welcome New User
@endcomponent
