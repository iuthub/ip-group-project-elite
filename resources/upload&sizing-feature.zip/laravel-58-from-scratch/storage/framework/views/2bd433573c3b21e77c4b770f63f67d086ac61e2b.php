<?php /* /Applications/XAMPP/xamppfiles/htdocs/laravel-58-from-scratch/resources/views/customers/create.blade.php */ ?>
<?php $__env->startSection('title', 'Add New Customer'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <h1>Add New Customer</h1>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <form action="<?php echo e(route('customers.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo $__env->make('customers.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <button type="submit" class="btn btn-primary">Add Customer</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>